SISTEMA JASS NUEVA ESPERANZA — VERSION WEB CON BASE DE DATOS

Incluye:
- Base de datos SQLite con WAL (apta para miles de registros; 5,000 usuarios es una carga pequeña para esta arquitectura).
- Inicio de sesión.
- Padrón de usuarios.
- Cobranza y lecturas.
- Numeración automática de recibos.
- Recibo imprimible / Guardar como PDF desde el navegador.
- Mantenimiento, cloración, calidad, captación, reservorio, redes e incidencias.
- Datos de la JASS.
- Panel de indicadores.

INSTALACION EN LAPTOP:
1. Instala Node.js LTS.
2. Abre una terminal dentro de esta carpeta.
3. Ejecuta: npm install
4. Ejecuta: npm start
5. Abre: http://localhost:3000

USUARIO INICIAL:
admin
CONTRASEÑA INICIAL:
admin123
IMPORTANTE: cambia la contraseña y SESSION_SECRET antes de usarlo en producción.

PARA USO MUNICIPAL REAL:
Se recomienda desplegarlo en un servidor con HTTPS, copias de seguridad, gestión de contraseñas con hash, roles/permisos completos, auditoría y almacenamiento de fotos. Esta entrega es una base funcional ejecutable, no un servicio público ya desplegado.
